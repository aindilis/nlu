swiplwebtut
===========

A tutorial for the swipl web framework

This tutorial is available online at

http://www.pathwayslms.com/swipltuts/html/index.html